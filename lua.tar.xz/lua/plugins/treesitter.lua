return {
	{
		"nvim-treesitter/nvim-treesitter",
		build = ":TSUpdate",
		event = { "BufReadPost", "BufNewFile" },
		opts = {
			ensure_installed = {
				"python",
				"lua",
				"markdown",
				"markdown_inline",
				"bash",
				"json",
				"yaml",
				"toml",
				"vim",
				"query",
			},
			highlight = {
				enable = true,
				-- rely on TS; if you prefer mixing with legacy regex, set to true
				additional_vim_regex_highlighting = false,
			},
			indent = { enable = true },
		},
		config = function(_, opts)
			require("nvim-treesitter.configs").setup(opts)
		end,
	},
}
