-- lua/plugins/lsp.lua
return {
	{
		-- You can keep lspconfig for its config "data", but we won't require it.
		"neovim/nvim-lspconfig",
		event = { "BufReadPre", "BufNewFile" },
		dependencies = {
			{ "williamboman/mason.nvim", build = ":MasonUpdate" },
			"williamboman/mason-lspconfig.nvim",
			"hrsh7th/nvim-cmp",
			"hrsh7th/cmp-nvim-lsp",
			"L3MON4D3/LuaSnip",
			"saadparwaiz1/cmp_luasnip",
			"folke/trouble.nvim",
		},
		config = function()
			-- Mason for installing servers
			local ok_mason, mason = pcall(require, "mason")
			if not ok_mason then
				return
			end
			mason.setup()

			local ok_mlc, mason_lspconfig = pcall(require, "mason-lspconfig")
			if not ok_mlc then
				return
			end

			-- Capabilities (with cmp integration if present)
			local caps = vim.lsp.protocol.make_client_capabilities()
			local ok_cmp, cmp_lsp = pcall(require, "cmp_nvim_lsp")
			if ok_cmp then
				caps = cmp_lsp.default_capabilities(caps)
			end

			-- Diagnostics UI
			vim.diagnostic.config({
				virtual_text = { spacing = 2, prefix = "●" },
				underline = true,
				severity_sort = true,
				update_in_insert = false,
				float = { border = "rounded", source = "if_many" },
			})
			local orig = vim.lsp.util.open_floating_preview
			vim.lsp.util.open_floating_preview = function(contents, syntax, opts, ...)
				opts = opts or {}
				opts.border = opts.border or "rounded"
				return orig(contents, syntax, opts, ...)
			end

			-- on_attach (keys + inlay hints)
			local function on_attach(client, bufnr)
				local map = function(mode, lhs, rhs, desc)
					vim.keymap.set(mode, lhs, rhs, { buffer = bufnr, silent = true, desc = desc })
				end
				map("n", "K", vim.lsp.buf.hover, "Hover")
				map("n", "gd", vim.lsp.buf.definition, "Definition")
				map("n", "gD", vim.lsp.buf.declaration, "Declaration")
				map("n", "gi", vim.lsp.buf.implementation, "Implementation")
				map("n", "gr", vim.lsp.buf.references, "References")
				map("n", "<leader>rn", vim.lsp.buf.rename, "Rename")
				map("n", "<leader>ca", vim.lsp.buf.code_action, "Code Action")
				map("n", "<leader>fd", vim.diagnostic.open_float, "Line Diagnostics")
				map("n", "[d", vim.diagnostic.goto_prev, "Prev Diagnostic")
				map("n", "]d", vim.diagnostic.goto_next, "Next Diagnostic")

				if
					client.server_capabilities
					and client.server_capabilities.inlayHintProvider
					and vim.lsp.inlay_hint
				then
					pcall(function()
						if type(vim.lsp.inlay_hint.enable) == "function" then
							vim.lsp.inlay_hint.enable(true, { bufnr = bufnr })
						else
							vim.lsp.inlay_hint(bufnr, true)
						end
					end)
				end
			end

			----------------------------------------------------------------------
			-- Native LSP configs (no require('lspconfig'))                      --
			-- Define with vim.lsp.config('<name>', { ... }); then enable.       --
			----------------------------------------------------------------------
			local servers = {
				pyright = {
					cmd = { "pyright-langserver", "--stdio" },
					filetypes = { "python" },
					root_markers = { "pyproject.toml", "setup.py", "setup.cfg", "requirements.txt", ".git" },
					capabilities = caps,
					on_attach = on_attach,
				},

				lua_ls = {
					cmd = { "lua-language-server" },
					filetypes = { "lua" },
					root_markers = { ".luarc.json", ".luarc.jsonc", ".stylua.toml", "stylua.toml", ".git" },
					capabilities = caps,
					on_attach = on_attach,
					settings = {
						Lua = {
							workspace = { checkThirdParty = false },
							diagnostics = { globals = { "vim" } },
							telemetry = { enable = false },
						},
					},
				},

				bashls = {
					cmd = { "bash-language-server", "start" },
					filetypes = { "sh", "bash" },
					root_markers = { ".git" },
					capabilities = caps,
					on_attach = on_attach,
				},

				jsonls = {
					cmd = { "vscode-json-languageserver", "--stdio" },
					filetypes = { "json", "jsonc" },
					root_markers = { ".git" },
					capabilities = caps,
					on_attach = on_attach,
				},

				yamlls = {
					cmd = { "yaml-language-server", "--stdio" },
					filetypes = { "yaml", "yml" },
					root_markers = { ".git" },
					capabilities = caps,
					on_attach = on_attach,
				},

				marksman = {
					cmd = { "marksman", "server" },
					filetypes = { "markdown" },
					root_markers = { ".git" },
					capabilities = caps,
					on_attach = on_attach,
				},
			}

			-- Ensure only these are installed; do NOT auto-install others (e.g., R)
			mason_lspconfig.setup({
				ensure_installed = vim.tbl_keys(servers),
				automatic_installation = false,
			})

			-- Define and enable each config natively
			for name, cfg in pairs(servers) do
				vim.lsp.config(name, cfg) -- define
				vim.lsp.enable(name) -- activate for its filetypes
			end
		end,
	},

	-- Completion
	{
		"hrsh7th/nvim-cmp",
		event = "InsertEnter",
		dependencies = { "hrsh7th/cmp-nvim-lsp", "L3MON4D3/LuaSnip", "saadparwaiz1/cmp_luasnip" },
		config = function()
			local ok_cmp, cmp = pcall(require, "cmp")
			if not ok_cmp then
				return
			end
			local ok_snip, luasnip = pcall(require, "luasnip")
			if not ok_snip then
				return
			end
			cmp.setup({
				snippet = {
					expand = function(args)
						luasnip.lsp_expand(args.body)
					end,
				},
				mapping = cmp.mapping.preset.insert({
					["<CR>"] = cmp.mapping.confirm({ select = true }),
					["<C-Space>"] = cmp.mapping.complete(),
					["<Tab>"] = cmp.mapping.select_next_item(),
					["<S-Tab>"] = cmp.mapping.select_prev_item(),
				}),
				sources = { { name = "nvim_lsp" }, { name = "luasnip" } },
			})
		end,
	},

	-- Diagnostics panel
	{
		"folke/trouble.nvim",
		cmd = { "Trouble", "TroubleToggle" },
		opts = { use_diagnostic_signs = true },
	},
}
