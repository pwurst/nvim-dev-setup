-- lua/plugins/conform.lua
return {
  {
    "stevearc/conform.nvim",
    event = { "BufWritePre" },
    -- Ensure commands are available even before the event fires
    cmd = { "ConformInfo", "ConformFormat" },

    opts = {
      -- Format on save with guards and per-ft overrides
      format_on_save = function(bufnr)
        -- Skip very large files
        local max_bytes = 500 * 1024
        local ok, st = pcall(vim.loop.fs_stat,
                             vim.api.nvim_buf_get_name(bufnr))
        if ok and st and st.size > max_bytes then
          return nil
          end

          -- Markdown: use prettierd, fall back to prettier, no LSP fallback
          if vim.bo[bufnr].filetype == "markdown" then
            return {
              timeout_ms = 2000,
              lsp_fallback = false,
              -- Try in order; Conform will use the first executable
              formatters = { "prettierd", "prettier" },
            }
            end

            -- Others: keep your defaults
            return { timeout_ms = 2000, lsp_fallback = true }
            end,

            -- Default formatter map (Markdown list provided at call time above)
            formatters_by_ft = {
              lua = { "stylua" },
              python = { "black" },
              yaml = { "yamlfmt" },
              -- markdown handled via format_on_save.formatters
            },

            -- Tool definitions / args
            formatters = {
              -- Daemon; no flags needed
              prettierd = {},

              -- CLI fallback; preserve manual line breaks in prose
              prettier = {
                prepend_args = { "--prose-wrap", "preserve" },
              },

              -- Keep YAML diffs tidy in metadata/config repos
              yamlfmt = {
                prepend_args = {
                  "--formatter",
                  "retain_line_breaks=true,trim_trailing_whitespace=true",
                },
              },
            },
    },
  },
}
