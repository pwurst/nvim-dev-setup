-- diagnostic_icons.lua
local signs = {
  Error = "",  -- nf-mdi-alert
  Warn  = "",  -- nf-mdi-alert_circle_outline
  Hint  = "",  -- nf-md-lightbulb_on_outline
  Info  = "",  -- nf-oct-info
}

return icons
