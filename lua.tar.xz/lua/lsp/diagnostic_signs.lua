local icons = require("lsp.diagnostic_icons")

vim.diagnostic.config({
  -- Keep inline noise low; use floating/hover as needed.
  virtual_text     = false,
  underline        = true,
  signs            = {
    text = {
      [vim.diagnostic.severity.ERROR] = icons.ERROR,
      [vim.diagnostic.severity.WARN]  = icons.WARN,
      [vim.diagnostic.severity.INFO]  = icons.INFO,
      [vim.diagnostic.severity.HINT]  = icons.HINT,
    },
  },
  update_in_insert = false,
})
