local M = {}

function M.setup(on_attach, capabilities)
-- Require inside setup() so Lazy-loaded plugins are available.
local mason       = require("mason")
local mason_lsp   = require("mason-lspconfig")
local lspconfig   = require("lspconfig")

-- Include every server you want installed + configured.
-- (Matches your warning list; ts_ls is the recent id for TS.)
local servers = {
  "bashls",
  "jedi_language_server",
  "ltex",
  "lua_ls",
  "marksman",
  "pyright",
  "ruff",
  "texlab",
  "ts_ls",
}

mason.setup()

mason_lsp.setup({
  ensure_installed       = servers,
  automatic_installation = true,
})

-- Register handlers that actually call lspconfig[server].setup{…}
mason_lsp.setup_handlers({
  -- Default handler for all servers.
  function(server_name)
  lspconfig[server_name].setup({
    on_attach    = on_attach,
    capabilities = capabilities,
  })
  end,

  -- Fine-tune Lua (Neovim runtime, disable built-in formatting, etc.)
["lua_ls"] = function()
lspconfig.lua_ls.setup({
  on_attach    = on_attach,
  capabilities = capabilities,
  settings = {
    Lua = {
      runtime = { version = "LuaJIT" },
      diagnostics = { globals = { "vim" } },
      workspace = { checkThirdParty = false },
      format = { enable = false }, -- use stylua via Conform/none-ls
        telemetry = { enable = false },
        hint = { enable = true },
    },
  },
})
end,
})
end

return M
